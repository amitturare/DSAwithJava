package com.sunidhi.RecursiomWithKunal;

public class PrintNumbers {
    public static void main(String[] args) {
        fun(5);
    }
    static void fun(int n){
        if(n == 0){
            return;
        }
        // ** for printing numbers from 5 to 1 **
//        System.out.println(n);
//        fun(n-1);
        // ** for printing numbers from 1 to 5 **
//        fun(n-1);
//        System.out.println(n);
        //for print numbers like 5432112345
        System.out.println(n);
        fun(n-1);
        System.out.println(n);
    }
}
