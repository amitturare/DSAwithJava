package com.sunidhi.RecursiomWithKunal.Arrays;

import java.util.ArrayList;

public class FindElements {
    public static void main(String[] args) {
        int[] arr = {2, 5, 8, 23 ,56 ,56,  89};
        int target = 56;
        System.out.println(findIndexB(arr, target, 0));
        System.out.println(findIndex(arr, target, 0));
        System.out.println(findIndexLast(arr, target, arr.length - 1));
        findAllElements(arr, target, 0);
        System.out.println(list);
        System.out.println(findIndexA(arr, target, 0, new ArrayList<>()));
    }
    static boolean findIndexB(int[] arr, int target, int index){
        if (index == arr.length){
            return false;
        }
        return arr[index] == target || findIndexB(arr, target, index +1);
    }
    static int findIndex(int[] arr, int target, int index){
        if(index == arr.length){
            return -1;
        }
        if(arr[index] == target){
            return index;
        }
        return findIndex(arr, target, index +1);
    }
    static int findIndexLast(int[] arr, int target, int index){
        if(index == -1){
            return -1;
        }
        if (arr[index] == target){
            return index;
        }
        return findIndexLast(arr, target, index -1);
    }
    static ArrayList<Integer> list = new ArrayList<>();
    static void findAllElements(int[] arr, int target, int index){
        if(index == arr.length){
            return;
        }
        if(arr[index] == target){
            list.add(index);
        }
        findAllElements(arr, target, index +1);
    }

    static ArrayList<Integer> findIndexA(int[] arr, int target, int index, ArrayList<Integer> list){
        if(index == arr.length){
            return list;
        }
        if(arr[index] == target){
            list.add(index);
        }
        return findIndexA(arr, target, index + 1, list);

    }

    
}
