package com.sunidhi.RecursiomWithKunal;

public class ReverseANumber {
    public static void main(String[] args) {
        //reverse(123);
        //reverse2(123);
        //System.out.println(sum);
        System.out.println(reverse3(123));

    }
    static void reverse(int n){
        if(n == 0){
            return;
        }
        System.out.print(n % 10);
        reverse(n / 10);
    }
    static int sum = 0;
    static void reverse2(int n){

        if(n == 0){
            return;
        }
        sum = sum * 10 + n % 10;
        reverse2(n / 10);
    }
    static int reverse3(int n){
        int digits = (int) (Math.log10(n));
        return helper(n , digits);
    }
    static int helper(int n, int digits){
        if(n % 10 == n){
            return n;
        }
        int rem = n % 10;
        return rem * (int)(Math.pow(10, digits)) + helper(n / 10, digits - 1);
    }
}
