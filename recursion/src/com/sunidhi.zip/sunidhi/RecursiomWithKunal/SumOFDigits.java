package com.sunidhi.RecursiomWithKunal;

public class SumOFDigits {
    public static void main(String[] args) {
        System.out.println(sOD(1234));
        System.out.println(pOD(1234));

    }
    static int sOD(int n){
        if(n == 0){
            return 0;
        }
        return n % 10 + sOD(n / 10);
    }
    static int pOD(int n){
        if(n % 10 == n){
            return n;
        }
        return n % 10 * pOD(n / 10);
    }
}
